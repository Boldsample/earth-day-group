<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
	public function index()
	{
		return User::all();
	}
	
	public function store(Request $request)
	{
		$request->validate([
			'username' => 'required',
			'email' => 'required',
			'name' => 'required',
			'password' => 'required'
		]);

		$user = new User();
		$user->username = $request->username;
		$user->email = $request->email;
		$user->name = $request->name;
		$user->location = $request->location;
		$user->bio = $request->bio;
		$user->phone = $request->phone;
		$user->password = $request->password;
		$user->save();

		return $user;
	}
	
	public function show(User $user)
	{
		return $user;
	}

	public function update(Request $request, User $user)
	{
		$request->validate([
			'username' => 'required',
			'email' => 'required',
			'name' => 'required',
			'password' => 'required'
		]);

		$user->name = $request->name;
		$user->location = $request->location;
		$user->bio = $request->bio;
		$user->phone = $request->phone;
		$user->password = $request->password;
		$user->update();

		return $user;
	}

	public function destroy($id)
	{
		$user = User::find($id);
		if(is_null($user))
			return response()->json('No se pudo realizar correctamente la operación', 404);
		$user->delete();
		return response()->noContent();
	}
}
